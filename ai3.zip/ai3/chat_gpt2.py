# chat_gpt2.py
import os
from transformers import GPT2Tokenizer, GPT2LMHeadModel

# ----------------------------
# Config
# ----------------------------
model_dir = "./gpt2-finetuned"
max_new_tokens = 150

# ----------------------------
# Load model
# ----------------------------
abs_model_dir = os.path.abspath(model_dir)
print(f"Loading fine-tuned GPT-2 from {abs_model_dir}...")
tokenizer = GPT2Tokenizer.from_pretrained(abs_model_dir, local_files_only=True)
model = GPT2LMHeadModel.from_pretrained(abs_model_dir, local_files_only=True)

# ----------------------------
# Chat loop
# ----------------------------
print("Chat with your GPT-2! Type 'exit' to quit.")
conversation_history = ""  # keeps track of previous messages

while True:
    prompt = input("\nYou: ")
    if prompt.lower() in ["exit", "quit"]:
        break

    # Include conversation history for context
    full_prompt = conversation_history + prompt
    inputs = tokenizer(full_prompt, return_tensors="pt")

    # Generate response (CPU-friendly)
    outputs = model.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        pad_token_id=tokenizer.eos_token_id,
        do_sample=True,
        top_p=0.9,
        temperature=0.8,
        eos_token_id=tokenizer.eos_token_id
    )

    generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    response = generated_text[len(full_prompt):].strip()

    print("GPT-2:", response)

    # Update conversation history
    conversation_history += prompt + " " + response + " "
