# train_gpt2.py
import os
from transformers import GPT2Tokenizer, GPT2LMHeadModel, Trainer, TrainingArguments, DataCollatorForLanguageModeling
from datasets import load_dataset

# ----------------------------
# Config
# ----------------------------
model_name = "gpt2"
dataset_file = "my_dataset.json"  # JSON file with "prompt" and "completion" keys
output_dir = "./gpt2-finetuned"
block_size = 256  # chunk size for long sequences

# ----------------------------
# Load model and tokenizer
# ----------------------------
print("Loading GPT-2 model and tokenizer...")
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)

# GPT-2 tokenizer does not have a padding token
tokenizer.pad_token = tokenizer.eos_token

# ----------------------------
# Load dataset
# ----------------------------
print("Loading dataset...")
dataset = load_dataset("json", data_files={"train": dataset_file})

# Combine prompt + completion
def concat_prompt_completion(example):
    text = example["prompt"] + " " + example["completion"]
    return {"text": text}

dataset = dataset.map(concat_prompt_completion)

# ----------------------------
# Tokenize and chunk
# ----------------------------
def tokenize_and_chunk(examples):
    tokenized_batch = tokenizer(examples["text"], add_special_tokens=True)
    input_ids_batch = tokenized_batch["input_ids"]

    chunked_input_ids = []
    chunked_attention_mask = []

    for input_ids in input_ids_batch:
        for i in range(0, len(input_ids), block_size):
            chunk = input_ids[i:i + block_size]
            chunked_input_ids.append(chunk)
            chunked_attention_mask.append([1] * len(chunk))

    return {"input_ids": chunked_input_ids, "attention_mask": chunked_attention_mask}

tokenized_datasets = dataset.map(
    tokenize_and_chunk,
    batched=True,
    remove_columns=dataset["train"].column_names
)

# ----------------------------
# Data collator
# ----------------------------
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# ----------------------------
# Training arguments
# ----------------------------
training_args = TrainingArguments(
    output_dir=output_dir,
    num_train_epochs=3,
    per_device_train_batch_size=2,
    logging_steps=10,
    save_steps=200,
    save_total_limit=2,
    learning_rate=5e-5,
    report_to="none",
    # fp16=True  <-- removed for CPU
)

# ----------------------------
# Trainer
# ----------------------------
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"],
    data_collator=data_collator
)

# ----------------------------
# Train
# ----------------------------
print("Starting training on CPU...")
trainer.train()

# ----------------------------
# Save the final model
# ----------------------------
print("Saving model and tokenizer...")
model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)
print(f"Training complete! Model saved to {os.path.abspath(output_dir)}")
